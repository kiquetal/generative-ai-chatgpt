
import psycopg2
from psycopg2 import sql
import random
import string
from datetime import datetime

# Configuration variables
DB_CONFIG = {
    'host': 'localhost',  # Database host
    'port': 5432,         # Database port
    'database': 'ai_network',  # Database name
    'user': 'your_user',  # Database username
    'password': 'your_password'  # Database password
}

# Establishing the database connection
def connect_db():
    try:
        conn = psycopg2.connect(
            host=DB_CONFIG['host'],
            port=DB_CONFIG['port'],
            dbname=DB_CONFIG['database'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password']
        )
        return conn
    except Exception as e:
        print("Error while connecting to PostgreSQL:", e)
        return None

# Generate random string for capabilities and task names
def generate_random_string(length=10):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

# Create agents
def create_agents(conn):
    agents = [
        ('Image Analyzer'),
        ('Narrative Creator'),
        ('Report Generator'),
        ('Text Translator'),
        ('Data Processor'),
        ('Audio Enhancer'),
        ('Video Editor'),
        ('Speech Recognizer'),
        ('Weather Predictor'),
        ('Social Media Monitor')
    ]

    cursor = conn.cursor()
    for agent_name in agents:
        cursor.execute("INSERT INTO agents (name) VALUES (%s) RETURNING agent_id", (agent_name,))
        agent_id = cursor.fetchone()[0]
        conn.commit()
        print(f"Agent '{agent_name}' inserted with agent_id: {agent_id}")
    cursor.close()

# Create capabilities
def create_capabilities(conn):
    capabilities = [
        ('Image Recognition', 'Ability to analyze and recognize objects in images'),
        ('Text Generation', 'Ability to create narratives and stories based on prompts'),
        ('Report Generation', 'Ability to generate detailed reports from datasets'),
        ('Speech Processing', 'Ability to process and understand speech'),
        ('Data Analysis', 'Ability to analyze large datasets and extract insights'),
        ('Social Media Analysis', 'Ability to analyze trends on social media platforms'),
    ]

    cursor = conn.cursor()
    cursor.execute("SELECT agent_id FROM agents")
    agent_ids = cursor.fetchall()
    
    for capability_name, description in capabilities:
        agent_id = random.choice(agent_ids)[0]
        cursor.execute(
            "INSERT INTO capabilities (agent_id, capability_name, description) VALUES (%s, %s, %s)",
            (agent_id, capability_name, description)
        )
        conn.commit()
        print(f"Capability '{capability_name}' inserted for agent_id: {agent_id}")
    cursor.close()

# Create tasks
def create_tasks(conn):
    tasks = [
        ('Analyze Images', 'Process a set of images for object recognition'),
        ('Generate Story', 'Create a short story based on a given theme'),
        ('Generate Quarterly Report', 'Generate a report based on sales data for Q1 2025'),
        ('Speech Recognition', 'Transcribe an audio clip into text'),
        ('Data Cleaning', 'Clean the dataset and remove duplicate entries'),
    ]

    cursor = conn.cursor()
    cursor.execute("SELECT agent_id FROM agents")
    agent_ids = cursor.fetchall()
    
    for task_name, description in tasks:
        agent_id = random.choice(agent_ids)[0]
        cursor.execute(
            "INSERT INTO tasks (agent_id, task_name, description, status) VALUES (%s, %s, %s, %s) RETURNING task_id",
            (agent_id, task_name, description, 'pending')
        )
        task_id = cursor.fetchone()[0]
        conn.commit()
        print(f"Task '{task_name}' inserted with task_id: {task_id}")
    cursor.close()

# Main function to populate the database
def populate_db():
    conn = connect_db()
    if conn is None:
        return
    
    # Create agents, capabilities, and tasks
    create_agents(conn)
    create_capabilities(conn)
    create_tasks(conn)
    
    # Close the connection
    conn.close()

if __name__ == "__main__":
    populate_db()
