
# AI Agent Network Database Populator

This script is used to populate the AI Agent Network database with sample data. The data includes agents, capabilities, tasks, interactions, task outputs, supervisors, and approvals. Ensure that the database is set up and configured before running the script.

## Requirements:
- Python 3.x
- psycopg2 library (for PostgreSQL interaction)

## Configuration:
Edit the configuration in the Python script (`DB_CONFIG` dictionary) to match your PostgreSQL database settings.

```python
DB_CONFIG = {
    'host': 'localhost',  # Database host
    'port': 5432,         # Database port
    'database': 'ai_network',  # Database name
    'user': 'your_user',  # Database username
    'password': 'your_password'  # Database password
}
```

## Usage:
1. Install the required dependencies:
   ```bash
   pip install psycopg2
   ```

2. Run the script to populate the database:
   ```bash
   python populate_db.py
   ```

## Notes:
- The script will insert agents, capabilities, interactions, tasks, task outputs, supervisors, and approvals into the database.
