
-- Table for AI Agents
CREATE TABLE agents (
    agent_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Table for Agent Capabilities
CREATE TABLE capabilities (
    capability_id SERIAL PRIMARY KEY,
    agent_id INTEGER REFERENCES agents(agent_id) ON DELETE CASCADE,
    capability_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Table for Interactions between Agents
CREATE TABLE interactions (
    interaction_id SERIAL PRIMARY KEY,
    agent_id_from INTEGER REFERENCES agents(agent_id) ON DELETE CASCADE,
    agent_id_to INTEGER REFERENCES agents(agent_id) ON DELETE CASCADE,
    interaction_type VARCHAR(50) NOT NULL,
    timestamp TIMESTAMP DEFAULT NOW(),
    notes TEXT
);

-- Table for Tasks and Outputs
CREATE TABLE tasks (
    task_id SERIAL PRIMARY KEY,
    agent_id INTEGER REFERENCES agents(agent_id) ON DELETE CASCADE,
    task_name VARCHAR(100) NOT NULL,
    description TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Table for Human Supervisors
CREATE TABLE supervisors (
    supervisor_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    role VARCHAR(50) DEFAULT 'Supervisor',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Table for Output Approvals
CREATE TABLE approvals (
    approval_id SERIAL PRIMARY KEY,
    task_id INTEGER REFERENCES tasks(task_id) ON DELETE CASCADE,
    supervisor_id INTEGER REFERENCES supervisors(supervisor_id) ON DELETE CASCADE,
    approved_at TIMESTAMP DEFAULT NOW(),
    comments TEXT
);

-- Indexes for faster lookup
CREATE INDEX idx_agent_capability ON capabilities(agent_id);
CREATE INDEX idx_task_agent ON tasks(agent_id);
CREATE INDEX idx_approval_task ON approvals(task_id);
CREATE INDEX idx_approval_supervisor ON approvals(supervisor_id);

-- Sample Data
INSERT INTO agents (name) VALUES ('NarrativeBot'), ('ImageAnalyzer'), ('ReportGenerator');
INSERT INTO supervisors (name, email) VALUES ('Alice Johnson', 'alice.j@example.com'), ('Bob Smith', 'bob.s@example.com');
