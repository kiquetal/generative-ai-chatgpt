
-- Package Design for AI Agent Social Network

-- 1. Agents Table
-- Stores AI agents and their basic information.
CREATE TABLE agents (
    agent_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- 2. Capabilities Table
-- Defines the capabilities of each AI agent.
CREATE TABLE capabilities (
    capability_id SERIAL PRIMARY KEY,
    agent_id INTEGER REFERENCES agents(agent_id) ON DELETE CASCADE,
    capability_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- 3. Interactions Table
-- Logs interactions between agents (e.g., collaborations, data exchanges).
CREATE TABLE interactions (
    interaction_id SERIAL PRIMARY KEY,
    agent_id_from INTEGER REFERENCES agents(agent_id) ON DELETE CASCADE,
    agent_id_to INTEGER REFERENCES agents(agent_id) ON DELETE CASCADE,
    interaction_type VARCHAR(50) NOT NULL,
    timestamp TIMESTAMP DEFAULT NOW(),
    notes TEXT
);

-- 4. Tasks Table
-- Records tasks assigned to agents.
CREATE TABLE tasks (
    task_id SERIAL PRIMARY KEY,
    agent_id INTEGER REFERENCES agents(agent_id) ON DELETE CASCADE,
    task_name VARCHAR(100) NOT NULL,
    description TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- 5. Task Outputs Table
-- Stores the results or outputs from tasks executed by agents.
CREATE TABLE task_outputs (
    output_id SERIAL PRIMARY KEY,
    task_id INTEGER REFERENCES tasks(task_id) ON DELETE CASCADE,
    output_data TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT NOW()
);

-- 6. Supervisors Table
-- Manages information for human supervisors who approve task outputs.
CREATE TABLE supervisors (
    supervisor_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    role VARCHAR(50) DEFAULT 'Supervisor',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- 7. Approvals Table
-- Tracks the task outputs that have been approved by supervisors.
CREATE TABLE approvals (
    approval_id SERIAL PRIMARY KEY,
    task_id INTEGER REFERENCES tasks(task_id) ON DELETE CASCADE,
    supervisor_id INTEGER REFERENCES supervisors(supervisor_id) ON DELETE CASCADE,
    approved_at TIMESTAMP DEFAULT NOW(),
    comments TEXT
);

-- Indexes for fast lookup
CREATE INDEX idx_agent_capability ON capabilities(agent_id);
CREATE INDEX idx_task_agent ON tasks(agent_id);
CREATE INDEX idx_approval_task ON approvals(task_id);
CREATE INDEX idx_approval_supervisor ON approvals(supervisor_id);
